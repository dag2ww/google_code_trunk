#FrequencyTimer2 Library#

Create a zero jitter frequency output, and run your own function on each period.

http://www.pjrc.com/teensy/td_libs_FrequencyTimer2.html

Originally written by Jim Studt.
