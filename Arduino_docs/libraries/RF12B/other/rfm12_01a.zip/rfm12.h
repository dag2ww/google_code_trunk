/**********************************************************
* rfm12.h
*
* HopeRf RFM12 FSK Wireless Module Library
*
* Copyright (c) 2007 Stephen Eaton
* 	seaton@everythingrobotics.com
*
* ===========================================================
* License:
*
*   Creative Commons - Attribution-Noncommercial-Share Alike 
*
* 	AU - http://creativecommons.org/licenses/by-nc-sa/2.5/au/
*	US - http://creativecommons.org/licenses/by-nc-sa/3.0/us/
*
*	All Other Countries please refer to the: 
*	  Attribution-Noncommercial-Share Alike License 
*	  for your country found on http://creativecommons.org/
*
* ===========================================================
*	History:
*
*	20071205 seaton - Initial ALPHA Release
*
**********************************************************/
#ifndef _RFM12_H_
#define _RFM12_H_

#include <system.h>
#include "..\common.h"

/*
  Define the SPI Connection Here  
  
      PIC				 RFM12
   +-------+           +-------+
   |       |		   |       |
   |     CS+-----------+nSEL   |
   |    SDO+-----------+SDI	   |
   |    SDI+-----------+SDO    |
   |    SCK+-----------+SCK    |
   |   nIRQ+-----------+nIRQ   |
   |       |           |       |
   +-------+		   +-------+
   
 The Pins defined below are looking from the PIC side
   
*/  

// Required Ports
#define RFM12_nIRQ_PORT		PORTB
#define RFM12_CS_PORT		PORTB
#define SCK_PORT			PORTC
#define SDO_PORT			PORTC
#define	SDI_PORT			PORTC

// TRIS Register
#define RFM12_nIRQ_TRISP	TRISB
#define RFM12_CS_TRISP		TRISB
#define SCK_TRISP			TRISC
#define SDO_TRISP			TRISC
#define	SDI_TRISP			TRISC

// Define pins
#define RFM12_nIRQ_PIN		0
#define RFM12_CS_PIN		1
#define	SCK_PIN				3
#define	SDI_PIN				4
#define	SDO_PIN				5

////////////////////////////////////////////////////////////
// DO NOT CHANGE BELOW THIS LINE
////////////////////////////////////////////////////////////
volatile bit rfm12_nIRQ     @ RFM12_nIRQ_PORT   . RFM12_nIRQ_PIN;
volatile bit rfm12_cs		@ RFM12_CS_PORT     . RFM12_CS_PIN;
volatile bit SCK			@ SCK_PORT     		. SCK_PIN;
volatile bit SDO			@ SDO_PORT		    . SDO_PIN;
volatile bit SDI			@ SDI_PORT     		. SDI_PIN;

bit RFM12_nIRQ_TRIS @ RFM12_nIRQ_TRISP . RFM12_nIRQ_PIN;
bit RFM12_CS_TRIS @ RFM12_CS_TRISP . RFM12_CS_PIN;
bit SCK_TRIS @ SCK_TRISP . SCK_PIN;
bit SDO_TRIS @ SDO_TRISP . SDO_PIN;
bit SDI_TRIS @ SDI_TRISP . SDI_PIN;

#define RFM12_CS_OUT()	RFM12_CS_TRIS=0
#define SCK_OUT()		SCK_TRIS=0
#define SDO_OUT()		SDO_TRIS=0	

#define RFM12_nIRQ_IN()	RFM12_nIRQ_TRIS=1
#define SDI_IN()		SDI_TRIS=1

////////////////////////////////////////////////////////////
// RFM12 SPI CMDs 
#define RFM12_CMD_CONFIG		0x8000		// Configuration
#define RFM12_CMD_POWERMGMT		0x8200		// Power management 
#define RFM12_CMD_FREQ			0xA000		// Frequency control
#define RFM12_CMD_RATE			0xC600		// Data rate
#define RFM12_CMD_RX_CTL		0x9000		// Receiver control
#define RFM12_CMD_FILTER_CTL	0xC200		// Filter control
#define RFM12_CMD_FIFORST_CTL	0xCA00		// FIFO and reset control
#define RFM12_CMD_SYNC			0xCE00		// Sync pattern
#define RFM12_CMD_FIFO_READ		0xB000		// FIFO read command
#define RFM12_CMD_AFC_CTL		0xC400		// AFC read command
#define RFM12_CMD_TX_CTL		0x9800		// Tx config control command
#define RFM12_CMD_PLL_CTL		0xCC00		// PLL control command
#define RFM12_CMD_TX_WRITE		0xB800		// Tx write buffer command
#define RFM12_CMD_WAKEUP		0xE100		// Wakeup timer command
#define RFM12_CMD_DUTYCYCLE		0xC800		// Duty cycle command
#define RFM12_CMD_LOWBAT_CLK	0xC000		// Low battery detector and CLK pin clock divider
#define RFM12_CMD_STATUS_READ	0x0000		// Read status Register

/////////////////////////////////////////////////////////////
// Command register offset values and bit masks
//
// If no offset or mask is defined then the offset is a single bit value
// 

/*
 RFM12_CMD_CONFIG
 BIT  15 14 13 12 11 10 9 8  7  6  5  4  3  2  1  0
      1   0  0  0  0  0 0 0  EL EF B1 B0 X3 X2 X1 X0 
*/
#define RFM12_8000_X_OFF		0x0			// Crystal load capacitance
#define RFM12_8000_X_MASK		0xF			// Crystal load bit mask
#define RFM12_8000_B_OFF		0x4			// Operating Band Selection	
#define RFM12_8000_B_MASK		0x3			// Operating Band Selection	mask
#define RFM12_8000_EF			0x40		// Enables FIFO Mode
#define RFM12_8000_EL			0x80		// Enable internal data register

#define SET_8000_EF(cmd) setbit(cmd,RFM12_8000_EF)
#define CLR_8000_EF(cmd) clearbit(cmd,RFM12_8000_EF)
#define SET_8000_EL(cmd) setbit(cmd,RFM12_8000_EL)
#define CLR_8000_EL(cmd) clearbit(cmd,RFM12_8000_EL)

/*
 RFM12_CMD_POWERMGMT
 BIT  15 14 13 12 11 10 9 8  7  6   5  4  3  2  1  0
      1   0  0  0  0  0 1 0  ER EBB ET ES EX EB EW DC 
*/
#define RFM12_8200_DC			0x00		// Disable clock
#define RFM12_8200_EW			0x02		// Enable wakeup
#define RFM12_8200_EB			0x04		// Enable low battery detector
#define RFM12_8200_EX			0x08		// Enable xtal Oscillator
#define RFM12_8200_ES			0x10		// enable synthesizer
#define RFM12_8200_ET			0x20		// enable transmitter
#define RFM12_8200_EBB			0x40		// enable base band block
#define RFM12_8200_ER			0x80		// enable receiver

#define SET_8200_DC(cmd) setbit(cmd,RFM12_8200_DC)
#define CLR_8200_DC(cmd) clearbit(cmd,RFM12_8200_DC)
#define SET_8200_EW(cmd) setbit(cmd,RFM12_8200_EW)
#define CLR_8200_EW(cmd) clearbit(cmd,RFM12_8200_EW)
#define SET_8200_EB(cmd) setbit(cmd,RFM12_8200_EB)
#define CLR_8200_EB(cmd) clearbit(cmd,RFM12_8200_EB)
#define SET_8200_EX(cmd) setbit(cmd,RFM12_8200_EX)
#define CLR_8200_EX(cmd) clearbit(cmd,RFM12_8200_EX)
#define SET_8200_ES(cmd) setbit(cmd,RFM12_8200_ES)
#define CLR_8200_ES(cmd) clearbit(cmd,RFM12_8200_ES)
#define SET_8200_ET(cmd) setbit(cmd,RFM12_8200_ET)
#define CLR_8200_ET(cmd) clearbit(cmd,RFM12_8200_ET)
#define SET_8200_EBB(cmd) setbit(cmd,RFM12_8200_EBB)
#define CLR_8200_EBB(cmd) clearbit(cmd,RFM12_8200_EBB)
#define SET_8200_ER(cmd) setbit(cmd,RFM12_8200_ER)
#define CLR_8200_ER(cmd) clearbit(cmd,RFM12_8200_ER)

/*
 RFM12_CMD_FREQ
 BIT  15 14 13 12 11  10   9  8  7  6  5  4  3  2  1  0
      1   0  1  0 F11 F10 F9 F8 F7 F6 F5 F4 F3 F2 F1 F0
*/
#define RFM12_A000_FREQ_OFF		0x0			// Operating frequency 
#define RFM12_A000_FREQ_MASK	0x7FF		// Operating frequency bit mask

/*
 RFM12_CMD_RATE
 BIT  15 14 13 12 11 10 9 8  7  6   5  4  3  2  1  0
      1   1  0  0  0  1 1 0  CS R6 R5 R4 R3 R2 R1 R0 
*/
#define RFM12_C600_R_OFF		0x0			// Data rate
#define RFM12_C600_R_MASK		0x5F		// Data rate bit mask
#define RFM12_C600_CS			0x80		// CS bit

/*
 RFM12_CMD_RX_CTL
 BIT  15 14 13 12 11 10  9   8  7  6  5  4  3  2  1  0
      1   0  0  1  0 P16 D1 D0 I2 I1 I0 G1 G0 R2 R1 R0
*/
#define RFM12_9000_R_OFF		0x0			// RSSI threshold
#define RFM12_9000_R_MASK		0x7			// RSSI threshold mask
#define RFM12_9000_G_OFF		0x3			// LNA gain
#define RFM12_9000_G_MASK		0x3			// LNA gain mask
#define RFM12_9000_I_OFF		0x5			// Receiver Bandwidth
#define RFM12_9000_I_MASK		0x7			// Receiver Bandwidth mask
#define RFM12_9000_D_OFF		0x8			// VDI Response time
#define RFM12_9000_D_MASK		0x3			// CDI response time mask
#define RFM12_9000_P16			0x400		// Pin 16 function - VDI output or interrupt input

#define SET_9000_P16(cmd) setbit(cmd,RFM12_9000_P16)
#define CLR_9000_P16(cmd) clearbit(cmd,RFM12_9000_P16)
/*
 RFM12_CMD_FILTER
 BIT  15 14 13 12 11 10 9 8  7  6  5 4 3 2  1  0
      1   1  0  0  0  0 1 0  AL ML 1 S 1 F2 F1 F0
 */
#define RFM12_C200_F_OFF		0x0			// DQD threshold
#define RFM12_C200_F_MASK		0x7			// DQD threshold mask
#define RFM12_C200_S			0x10		// Filter Type 0=digital 1=analogue
#define RFM12_C200_ML			0x40		// Clock recovery lock control
#define RFM12_C200_AL			0x80		// Clock recovery lock

#define SET_C200_S(cmd) setbit(cmd,RFM12_C200_S)
#define CLR_C200_S(cmd) clearbit(cmd,RFM12_C200_S)
#define SET_C200_ML(cmd) setbit(cmd,RFM12_C200_ML)
#define CLR_C200_ML(cmd) clearbit(cmd,RFM12_C200_ML)
#define SET_C200_AL(cmd) setbit(cmd,RFM12_C200_AL)
#define CLR_C200_AL(cmd) clearbit(cmd,RFM12_C200_AL)


/*
 RFM12_CMD_FIFORST_CTL
 BIT  15 14 13 12 11 10 9 8  7  6   5  4 3   2  1  0
      1   1  0  0  1  0 1 0  F3 F2 F1 F0 SP AL FF DR
 */
#define RFM12_CA00_DR			0x00		// Disable Reset Mode
#define RFM12_CA00_FF			0x02		// FIFO fill enabled after reception of Sync pattern
#define RFM12_CA00_AL			0x04		// Fifo Fill start condition 0=sync, 1=Always fill
#define RFM12_CA00_SP			0x08		// Length of Sync Patten 0=2 bytes (0x2DD4), 1=1byte(0xD4)
#define RFM12_CA00_F_OFF		0x4			// FIFO Interrupt Level, generates IT when x number of bits received
#define RFM12_CA00_F_MASK		0xF			// FIFO Interrupt Level mask

#define SET_CA00_DR(cmd) setbit(cmd,RFM12_CA00_DR)
#define CLR_CA00_DR(cmd) clearbit(cmd,RFM12_CA00_DR)
#define SET_CA00_FF(cmd) setbit(cmd,RFM12_CA00_FF)
#define CLR_CA00_FF(cmd) clearbit(cmd,RFM12_CA00_FF)
#define SET_CA00_AL(cmd) setbit(cmd,RFM12_CA00_AL)
#define CLR_CA00_AL(cmd) clearbit(cmd,RFM12_CA00_AL)
#define SET_CA00_SP(cmd) setbit(cmd,RFM12_CA00_SP)
#define CLR_CA00_SP(cmd) clearbit(cmd,RFM12_CA00_SP)

/*
 RFM12_CMD_SYNC
 BIT  15 14 13 12 11 10 9 8  7  6  5   4  3  2  1  0
      1   1  0  0  1  1 1 0  B7 B6 B5 B4 B3 B2 B1 B0
 */
#define RFM12_CE00_B_OFF		0x0			// Sync Patten - User programmable
#define RFM12_CE00_B_MASK		0xFF		// Sync Patten mask

/*
 RFM12_CMD_AFC_CTL
 BIT  15 14 13 12 11 10 9 8  7  6    5   4  3  2  1  0
      1   1  0  0  0  1 0 0  A1 A0 RL1 RL0 ST FI OE EN
 */
#define RFM12_C400_EN			0x00		// AFC Enable
#define	RFM12_C400_OE			0x02		// AFC Enable frequency offset register
#define	RFM12_C400_FI			0x04		// AFC Enable High Accurracy (fine) mode
#define RFM12_C400_ST			0x08		// AFC Strobe Edge When high AFC latest is stored in offset register
#define RFM12_C400_RL_OFF		0x4			// AFC Range Limit
#define RFM12_C400_RL_MASK		0x3			// AFC Range Limit bit mask
#define RFM12_C400_A_OFF		0x6			// AFC Automatic Mode
#define	RFM12_C400_A_MASK		0x3			// AFC Automatic mask

#define SET_C400_EN(cmd) setbit(cmd,RFM12_C400_EN)
#define CLR_C400_EN(cmd) clearbit(cmd,RFM12_C400_EN)
#define SET_C400_OE(cmd) setbit(cmd,RFM12_C400_OE)
#define CLR_C400_OE(cmd) clearbit(cmd,RFM12_C400_OE)
#define SET_C400_FI(cmd) setbit(cmd,RFM12_C400_FI)
#define CLR_C400_FI(cmd) clearbit(cmd,RFM12_C400_FI)
#define SET_C400_ST(cmd) setbit(cmd,RFM12_C400_ST)
#define CLR_C400_ST(cmd) clearbit(cmd,RFM12_C400_ST)
/*
 RFM12_CMD_TX_CTL
 BIT  15 14 13 12 11 10 9 8  7  6  5  4  3 2  1  0
      1   0  0  1  1  0 0 MP M3 M2 M1 M0 0 P2 P1 P0
*/
#define RFM12_9800_P_OFF		0x0		// Tx power
#define RFM12_9800_P_MASK		0x7		// Tx power mask
#define RFM12_9800_M_OFF		0x4		// FSK Modulation parameter
#define RFM12_9800_M_MASK		0xF		// FSK modulation parameter mask

/*
 RFM12_CMD_PLL_CTL
 BIT  15 14 13 12 11 10 9 8  7  6   5    4   3   2  1  0
      1   1  0  0  1  1 0 0  0 OB1 OB0 LPX DDY DDIT 1 BW0
*/
#define RFM12_CC00_BW_OFF		0x0			// PLL bandwidth 
#define RFM12_CC00_BW_MASK		0x03		// PLL bandwidth mask
#define RFM12_CC00_DDIT			0x04		// Disables Dithering in PLL Loop
#define RFM12_CC00_DDY			0x08		// Phase Detector Delay
#define RFM12_CC00_LPX			0x10		// Low Power mode of Crystal
#define RFM12_CC00_OB_OFF		0x5			// Output clock buffer
#define RFM12_CC00_OB_MASK		0x3			// Output clock buffer mask

#define SET_CC00_DDIT(cmd) setbit(cmd,RFM12_CC00_DDIT)
#define CLR_CC00_DDIT(cmd) clearbit(cmd,RFM12_CC00_DDIT)
#define SET_CC00_DDY(cmd) setbit(cmd,RFM12_CC00_DDY)
#define CLR_CC00_DDY(cmd) clearbit(cmd,RFM12_CC00_DDY)
#define SET_CC00_LPX(cmd) setbit(cmd,RFM12_CC00_LPX)
#define CLR_CC00_LPX(cmd) clearbit(cmd,RFM12_CC00_LPX)

/*
 RFM12_CMD_TX_WRITE
 BIT  15 14 13 12 11 10 9 8  7  6  5  4  3  2  1  0
      1   1  0  0  1  0 0 0  T7 T6 T5 T4 T3 T2 T1 T0
 */
#define RFM12_B800_T			0x0			// Transmit Register Write
#define RFM12_B800_T_MASK		0xF			// Transmit Register Write Mask

/*
 RFM12_CMD_WAKEUP
 BIT  15 14 13 12 11 10 9  8  7  6  5  4  3  2  1  0
      1   1  1 R4 R3 R2 R1 R0 M7 M6 M5 M4 M3 M2 M1 M0
 */
#define	RFM12_E100_M_OFF		0x0		// Wakeup time period
#define	RFM12_E100_M_MASK		0xFF	// Wakeup time period mask
#define	RFM12_E100_R_OFF		0x8		// Wakeup time period use values 0-29
#define	RFM12_E100_R_MASK		0x1F	// Wakeup time period mask

/*
 RFM12_CMD_DUTYCYCLE
 BIT  15 14 13 12 11 10 9 8  7  6  5  4  3  2  1  0
      1   1  0  0  1  0 0 0 D6 D5 D4 D3 D2 D1 D0 EN
 */
#define RFM12_C800_EN			0x0			// Enable low duty-cycle mode
#define RFM12_C800_D_OFF		0x1			// Duty-cycle
#define RFM12_C800_D_MASK		0xFE		// Duty-cycle mask

#define SET_C800_EN(cmd) setbit(cmd,RFM12_C800_EN)
#define CLR_C800_EN(cmd) clearbit(cmd,RFM12_C800_EN)

/*
 RFM12_CMD_LOWBAT_CLK
 BIT  15 14 13 12 11 10 9 8  7  6  5  4  3  2  1  0
      1   1  0  0  0  0 0 0  D2 D1 D0 0 V3 V2 V1 V0
 */
#define RFM12_C000_V_OFF		0x0			// Voltage
#define RFM12_C000_MASK			0xF			// voltage Mask
#define RFM12_C000_D_OFF		0x4			// CLK Frequency
#define RFM12_C000_DMASK		0xE			// CLK Frequency Mask

/*
 RFM12_0000_STATUS_READ
 BIT  15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0
      0  X  X  X  X  X  X X X X X X X X X X 
      
      This is result of status read
*/
#define RFM12_0000_RGIT_FFIT	0x8000		// TX ready for next byte or FIFO received data Status
											// depends on mode of transmitter
											
#define RFM12_0000_POR			0x4000		// Power on Reset Status
#define RFM12_0000_RGUR_FFOV	0x2000		// TX Register underun or RX FIFO Overflow Status
											// depends on mode of transmitter

#define RFM12_0000_WKUP			0x1000		// Wakeup Timer overflow Status
#define RFM12_0000_EXT			0x0800		// Interrup on external source Status
#define RFM12_0000_LBD			0x0400		// Low battery detect Status
#define RFM12_0000_FFEM			0x0200		// FIFO Empty Status
#define RFM12_0000_ATS			0x0100		// Antenna Tuning Signal Detect Status
#define RFM12_0000_RSSI			0x0080		// Received Signal Strength Indicator Status
#define RFM12_0000_DQD			0x0040		// Data Quality Dedector Status
#define RFM12_0000_CRL			0x0020		// Clock Recovery Locked status
#define RFM12_0000_ATGL			0x0010		// Toggling in each AFC Cycle
#define RFM12_0000_OFFS_SIGN	0x0008		// Measured Offset Frequency Sign Value 1='+', 0='-' 
#define RFM12_0000_OFFS			0x0004		// Measured offset Frequency value (3 bits) 
#define RFM12_0000_OFFS_MASK	0x0003		// Measured offset mask

#define isRGITFFIT (1 << RFM12_0000_RGIT_FFIT)
#define isPOR  (1 << RFM12_0000_POR)
#define isRGURFFOV (1 << RFM12_0000_RGUR_FFOV)
#define isWKUP (1 << RFM12_0000_WKUP)
#define isEXT (1 << RFM12_0000_EXT)
#define isLBD (1 << RFM12_0000_LBD)
#define isFFEM (1 << RFM12_0000_FFEM)
#define isATS (1 << RFM12_0000_ATS)
#define isRSSI (1 << RFM12_0000_RSSI)
#define isDQD (1 << RFM12_0000_DQD)
#define isCRL (1 << RFM12_0000_CRL)
#define isATGL (1 << RFM12_0000_ATGL)

////////////////////////////////////////////////////////////
// Configuration Parameters 
// POR = power on reset values

/*
	.band - Band of module
	
	The band is module specific and needs to be matched to the physical 
	RFM12 module you have.  If in doubt check the back of the RFM module.
	
	i.e. you can't set 915Mhz if your module is physically a 433Mhz
	
*/
#define RFM12_BAND_NONE		0x0		// POR
#define RFM12_BAND_433		0x1		// 433MHz
#define RFM12_BAND_868		0x2		// 868MHz 	// Not implemented
#define RFM12_BAND_915		0x3		// 915MHz

/*
 .power - Tx Output Power
 
	The output power is relative to the maximium 
	power available, which depnds on the actual 
	antenna impedenance.
 */
#define RFM12_POWER_0		0x0		//  0dB - POR
#define RFM12_POWER_3		0x1		// -3dB
#define RFM12_POWER_6		0x2		// -6dB
#define RFM12_POWER_9		0x3		// -9dB
#define RFM12_POWER_12		0x4		// -12dB
#define RFM12_POWER_15		0x5		// -15dB
#define RFM12_POWER_18		0x6		// -18dB
#define RFM12_POWER_21		0x7		// -21dB

/*
 .clk_speed  - speed of external CLK Pin
 
  Divider for the internal RFM12 Oscillator on the 
  External CLK ping can be used as clock source source 
  for a uController.
  
  Also needs the DC bit(bit 0) cleared in the 
  Power management Register to enable CLK Pin.
  
 */
#define RFM12_XTAL_100		0x0		// 1.00MHz - POR
#define RFM12_XTAL_125		0x1		// 1.25MHz
#define RFM12_XTAL_166		0x2		// 1.66MHZ
#define RFM12_XTAL_200		0x3		// 2.00MHZ
#define RFM12_XTAL_250		0x4		// 2.50MHZ
#define RFM12_XTAL_333		0x5		// 3.33MHZ
#define RFM12_XTAL_500		0x6		// 5.00MHZ
#define RFM12_XTAL_1000		0x7		// 10.00MHZ

/*
 .bandwidth
 
 Table of optimal bandwidth and transmitter 
 deviation settings for given data rates 
 
 (the data sheet was a bit vague in this area and 
  did not specify frequencies etc so I don't know 
  how valid they are at different frequency bands 
  but they could be used as a starting point)
 
 data rate		bandwidth		deviation
 1200bps		67kHz			45kHz
 2400			67				45
 4800			67				45
 9600			67				45
 19200			67				45
 38400			134				90
 57600			134				90
 115200			200				120
 
 */
#define RFM12_BW_400		0x1		// 400kHz
#define RFM12_BW_340		0x2		// 340kHz
#define RFM12_BW_270		0x3		// 270kHz
#define RFM12_BW_200		0x4		// 200kHz - POR 
#define RFM12_BW_134		0x5		// 134kHz
#define RFM12_BW_67			0x6		// 67kHz

/*
	.modulation  - Frequency Deviation
	
	Transmit FSK Modulation Control
	
	modulation (kHz) = f0 + (-1)^sign * (M +1) * (15kHZ)
	
	Where:
		f0 	 = channel centre frequency
		M 	 = 4 bit binary bumber <m3:m0>
		SIGN = (mp) XOR (Data bit)

			
			Pout
				^
				|		^		|		^
				|		|		|		|
				|		|		|		|
				|		|<dfFSK>|<dfFSK>|
				|		|		|		|
				|		|		|		|
				+-------+-------+-------+--------> fout
								f0
						^				^
						|				+------- mp=0 and FSK=1 or mp=1 and FSK=0
						|
						+------------------------mp=0 and FSK=0 or mp=1 and FSK=1
						
						
*/
#define RFM12_MODULATION_15		0x0		// 15 kHz - POR
#define RFM12_MODULATION_30		0x1		// 35 kHz
#define RFM12_MODULATION_45		0x2		// 45 kHz
#define RFM12_MODULATION_60		0x3		// 45 kHz
#define RFM12_MODULATION_75		0x4		// 75 kHz
#define RFM12_MODULATION_90		0x5		// 90 kHz
#define RFM12_MODULATION_105	0x6		// 105 kHz
#define RFM12_MODULATION_120	0x7		// 120 kHz
#define RFM12_MODULATION_135	0x8		// 135 kHz
#define RFM12_MODULATION_150	0x9		// 150 kHz
#define RFM12_MODULATION_165	0xA		// 165 kHz
#define RFM12_MODULATION_180	0xB		// 180 kHz
#define RFM12_MODULATION_195	0xC		// 195 kHz
#define RFM12_MODULATION_210	0xD		// 210 kHz
#define RFM12_MODULATION_225	0xE		// 225 kHz
#define RFM12_MODULATION_240	0xF		// 240 kHz

/*
	.bitrate - RF baudrate 

	7 bit value
	
	Value of register is calculated as:
	
	bitRate = 344828 / (1 + cs*7) / (BR- 1)
		
	Where:
	bitrate = 7 bit value
	cs = 0 or 1
	BR = Required bitrate in kbps  i.e. 9.600 = 9600bps

	So any value from 600 - 115200 can be calculated
	below is some standard ones and their CS value
*/
#define RFM12_BITRATE_115200	0x02	// 115.2 kbps	CS=0
#define RFM12_BITRATE_57600		0x05	// 57600 bps	CS=0
#define RFM12_BITRATE_19200		0x11	// 19200 bps  	CS=0
#define RFM12_BITRATE_9600		0x23	// 9600  bps 	CS=0
#define RFM12_BITRATE_4800		0x47	// 4800 bps  	CS=0
#define RFM12_BITRATE_2400		0x8F	// 2400 bps  	CS=1
#define RFM12_BITRATE_1200		0xA3	// 1200	bps  	CS=1

/*
	.afc   Automatic Frequency Control
	
	RFM12_AFC_PWRUP  Recommended for Max distance
	RFM12_AFC_VDI 	 Recommended for receiving from Multiple Transmitters (Point To Multipoint) 
	RFM12_AFC_nVDI	 Recommended for receiving from Single Transmitter (PtP)
	
*/ 
#define RFM12_AFC_MCU			0x0		// Controlled by MCU
#define RFM12_AFC_PWRUP			0x1		// Runs Once at powerup
#define RFM12_AFC_VDI			0x2		// Keeps Offset when VDI High
#define RFM12_AFC_nVDI			0x3		// Keeps Offset independent of VDI - POR

/* 
 .afc_range
 
	Limits the value of the frequency offset register to the next values
	
	fRes:
		315,433Mhz bands: 	2.5kHz
		868MHz band:		5.0kHz
		915MHz band:		7.5kHz
 
 */
#define RFM12_AFC_RNG_NONE  0x0		// No Restriction
#define RFM12_AFC_RNG_1516	0x1		// +15/-16
#define RFM12_AFC_RNG_0708	0x2		// +7/-8
#define RFM12_AFC_RNG_0304	0x3		// +3/-4  - POR

/*
 .loadcap - Crystal load Capacitor
 
 Can be used to adjust/Calibrate the XTAL Frequency startup time

 */
#define RFM12_CAP_085		0x0		//  8.5pF
#define RFM12_CAP_090		0x1		//  9.0pF
#define RFM12_CAP_095		0x2		//  9.5pF
#define RFM12_CAP_100		0x3		// 10.0pF
#define RFM12_CAP_105		0x4		// 10.5pF
#define RFM12_CAP_110		0x5		// 11.0pF
#define RFM12_CAP_115		0x6		// 11.5pF
#define RFM12_CAP_120		0x7		// 12.0pF
#define RFM12_CAP_125		0x8		// 12.5pF - POR
#define RFM12_CAP_130		0x9		// 13.0pF
#define RFM12_CAP_135		0xA		// 13.5pF
#define RFM12_CAP_140		0xB		// 14.0pF
#define RFM12_CAP_145		0xC		// 14.5pF
#define RFM12_CAP_150		0xD		// 15.0pF
#define RFM12_CAP_155		0xE		// 15.5pF
#define RFM12_CAP_160		0xF		// 16.0pF 

/*
	.rssi - Relative Signal Strength Indicator
	
	As the RSSI Threshold relies on the LNA gain
	the true RSSI can be calculated by:
	
	RDDIth 	= RSSIsetth + Glna
	
   Where:
	RSSIth 	= RSSI Threshold (Actual)
	RSSIsetth = RSSI Set Threshold (from below)
	Glna	= Gain LNA	 (from below)
*/
#define RFM12_RSSI_103		0x0		// -103dB - POR
#define RFM12_RSSI_97		0x1		// -97dB 
#define RFM12_RSSI_91		0x2		// -91dB 
#define RFM12_RSSI_85		0x3		// -85dB 
#define RFM12_RSSI_79		0x4		// -79dB 
#define RFM12_RSSI_73		0x5		// -73dB 

/*
	.lna - Rx Low noise amplifier Relative to Max 
 */
#define RFM12_LNA_0			0x0		// -0dB - POR
#define RFM12_LNA_6			0x1		// -6dB 
#define RFM12_LNA_14		0x2		// -14dB 
#define RFM12_LNA_20		0x3		// -20dB 

/* 
	.dqd - Data Quality Detection
*/


/*
	.lowbat_threshold
	
	The EB bit (bit 2) needs to be set in the Power Management 
	Register (C8200) to enable the Low Battery Monitor
*/
#define RFM_LOWBAT_2_2		0x0		// 2.2V  - POR
#define RFM_LOWBAT_2_3		0x1		// 2.3V
#define RFM_LOWBAT_2_4		0x2		// 2.4V
#define RFM_LOWBAT_2_5		0x3		// 2.5V
#define RFM_LOWBAT_2_6		0x4		// 2.6V
#define RFM_LOWBAT_2_7		0x5		// 2.7V
#define RFM_LOWBAT_2_8		0x6		// 2.8V
#define RFM_LOWBAT_2_9		0x7		// 2.9V
#define RFM_LOWBAT_3_0		0x8		// 3.0V
#define RFM_LOWBAT_3_1		0x9		// 3.1V
#define RFM_LOWBAT_3_2		0xA		// 3.2V
#define RFM_LOWBAT_3_3		0xB		// 3.3V
#define RFM_LOWBAT_3_4		0xC		// 3.4V
#define RFM_LOWBAT_3_5		0xD		// 3.5V
#define RFM_LOWBAT_3_6		0xE		// 3.6V
#define RFM_LOWBAT_3_7		0xF		// 3.7V

// .powermgmt  power management
#define RFM12_TX_OFF		0x0		// Transmitter Off - POR
#define RFM12_TX_ON			0x1		// Transmitter On

#define RFM12_RX_OFF		0x0		// Receiver Off - POR
#define RFM12_RX_ON			0x1		// Receiver On

#define RFM12_EBB_OFF		0x0		// Base Band Block Off - POR
#define RFM12_EBB_ON		0x1		// Base Band Block On

#define RFM12_SYNTH_OFF		0x0		// Synthesizer Off - POR
#define RFM12_SYNTH_ON		0x1		// Synthesizer On

#define RFM12_XTAL_OFF		0x0		// Crystal Oscillacitor Off
#define RFM12_XTAL_ON		0x1		// Crystal Oscillacitor On - POR

#define RFM12_LOWBAT_OFF	0x0		// Low Battery detector off - POR
#define RFM12_LOWBAT_ON		0x1		// Low Battery detector on

#define RFM12_CLK_OFF		0x1		// CLK pin off
#define RFM12_CLK_ON		0x0		// CLK pin on - POR

#define RFM12_WAKEUP_OFF	0x0		// wakeup timer disabled - POR
#define RFM12_WAKEUP_ON		0x1		// Wakeup timer enabled

/*
	.txrx_mode
*/
#define RFM12_MODE_MASTER_RX		0x0		// RX Mode - Master
#define RFM12_MODE_MASTER_TX		0x1		// TX Mode - Master
#define RFM12_MODE_SLAVE_RX			0x2		// RX Mode - Slave
#define RFM12_MODE_SLAVE_TX			0x3		// TX Mode - Slave
//#define RFM12_MODE_RX_HOP	0x2		// RX Mode Freq Hopping
//#define RFM12_MODE_TX_HOP	0x3		// TX Mode Freq hopping

/* 
	.freq  - Frequency Control

	Frequency is an 11bit value 
	calculated by:
	
	f0 = 10 * C1 * (C2 + F/4000) [MHz]
	
	 or
	
	F = (f0 - 900)/0.0075   (915MHz)
	F = (f0 - 430)/0.0025	(433MHz)
	
	Where:
	
	f0	= Centre Frequency in MHz
	F 	= 11 bit register value maps to f11:f0 of the Frequency CMD Register (A000)
	
	Band (MHz)	C1	C2
	====================
	433			1	43
	868			2	43
	915			3	30

*/
#define RFM12_FREQ_433(FREQ)  (uint)((FREQ-430)/0.0025)	// Calculate the RFM12 register value for a given Frequency at 433MHz
#define RFM12_FREQ_915(FREQ)  (uint)((FREQ-900)/0.0075)	// Calculate the RFM12 register value for a given Frequency at 915MHz

/* 
	.wakeup_period
	
	T = M * 2^R 
	
	Where:
	T = Time in ms of wakeup timer
	M = 8 bit value	- maps to bits 7 - 0 of Wake up timer command Register
	R = 5 bit value - maps to bits 12- 8 of Wake up timer command Register
	
	NOTE:  
		1) For future compatibility  0 <= R <= 29
		2) For continual Operation the EW bit should be cleared and 
		   set at end of every cycle.
*/

typedef enum 
{ 
   RFM12_STATE_POWERINGTRANSMITTER = 1,
   RFM12_STATE_TRANSMITTING = 2,
   RFM12_STATE_RECEIVING    = 3,
   RFM12_STATE_QUIETTIME    = 4
} RFM12_STATE;


/*---------------------------------------------------------
 NOT IMPLEMENTED
 Most of the configurable bits of the RFM12 chip are mapped
 into this structure
 ---------------------------------------------------------*/
struct _rfm12_t {
	// State
	RFM12_STATE state;			// current state of tranceiver
	
	uchar	channel;			// current channel
	
	// status
	uint  status;				// Readonly - Status register of RM12
};
typedef struct _rfm12_t rfm12_t;

////////////////////////////////////////////////////////////////////////////////////////////
//
// function definitions
//
void rfm12_Init_433(void);				// Initialiases the RFM12 for 433MHz band
void rfm12_Init_915(void);				// Initialiases the RFM12 for 915MHz band

void rfm12_SetBaud(uint baud);			// sets RF baud rate
void rfm12_SetBandwidth(uchar bandwidth, uchar gain, uchar drssi);   // Sets the bandwidth, gain and drssi		
void rfm12_SetFreq(uint freq);			// Sets the Frequency 
void rfm12_SetPower(uchar power, uchar modulation); // Sets power and modulation of Tx
void rfm12_EnableTx(void);				// Enables Transmitter circuit
void rfm12_EnableRx(void);				// Enables Receiver circuit
void rfm12_DisableTx(void);				// Disables Transmitter
void rfm12_disableRx(void);				// Disables Receiver

uchar rfm12_isReady(void);				// Waits until rfm12 is ready (Tx/Rx) with timeout
void rfm12_WaitReady(void);				// Waits until rfm12 is ready (Tx/Rx) without timeout

void rfm12_Init_Buffer(void);			// Initialiase the Tx/Rx Buffer
void rfm12_Load_Byte(uchar data);		// Load a byte into Tx Buffer
uchar rfm12_Read_Buffer(uchar index);	// reads byte from buffer
void rfm12_Tx_Byte(uchar data);			// Transmit a single byte
void rfm12_Tx_Buffer(void);				// Transmit the entire buffer
void rfm12_Rx_Data(uchar count);		// Receives data
void rfm12_ResetFifo(void);				// Resets the Rx FIFO buffer on the RFM12
uchar rfm12_ReadFifo(void);				// Reads the Fifo and returns data

// these functions not yet implemented			
void rfm12_Handle_Interrupt(void);		// Interrupt callback						

#endif //_RFM12_H_
